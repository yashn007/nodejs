module.exports = {
  secret: '148bc74348d21ed807469a1e0acb2342'
}
